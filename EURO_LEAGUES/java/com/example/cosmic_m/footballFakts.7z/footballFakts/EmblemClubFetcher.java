package com.example.cosmic_m.footballFakts;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;

import com.applantation.android.svg.SVG;
import com.applantation.android.svg.SVGParseException;
import com.applantation.android.svg.SVGParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 * Created by Cosmic_M on 30.05.2017.
 */

public class EmblemClubFetcher implements Callable<Map<String, Drawable>>{
    private static final String TAG = "TT";
    private String[] links;

    EmblemClubFetcher(String[] links){
        this.links = links;
    }

    public Map<String, Drawable> call() throws IOException {
        Map<String, Drawable> emblems = new HashMap<>();
        for (String link : links) {
            if (link.endsWith("svg")) {
                URL url = new URL(link);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                String redirect = connection.getHeaderField("Location");
                if (redirect != null) {
                    connection = (HttpURLConnection) new URL(redirect).openConnection();
                }

                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    InputStream in = connection.getInputStream();
                    if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                        Log.i(TAG, "not valid link, -> " + link.toString());
                        Log.i(TAG, "message: " + new Exception(connection.getResponseMessage()));
                        throw new IOException(connection.getResponseMessage() + " with " + link);
                    }
                    SVG svg = null;
                    try {
                        svg = SVGParser.getSVGFromInputStream(in);
                    } catch (SVGParseException exc) {
                        Log.i(TAG, "NumberFormatException worked");
                        //return new OtherEmblemClubFetcher().getUrlBytes(link);
                        Drawable drawable =  new OtherEmblemClubFetcher().getUrlBytes(link);
                        emblems.put(link, drawable);
                    }
                    Drawable drawable = svg.createPictureDrawable();
                    //return drawable;
                    emblems.put(link, drawable);
                } finally {
                    connection.disconnect();
                }
            } else {
                URL url = new URL(link);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                String redirect = connection.getHeaderField("Location");
                if (redirect != null) {
                    connection = (HttpURLConnection) new URL(redirect).openConnection();
                }

                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    InputStream in = connection.getInputStream();
                    if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                        Log.i(TAG, "not valid link, -> " + link.toString());
                        Log.i(TAG, "message: " + new Exception(connection.getResponseMessage()));
                        throw new IOException(connection.getResponseMessage() + " with " + link);
                    }
                    int readBytes;
                    byte[] buffer = new byte[1024];
                    while ((readBytes = in.read(buffer)) > -1) {
                        out.write(buffer, 0, readBytes);
                    }
                    out.close();
                    byte[] bytesFromURL = out.toByteArray();
                    Bitmap bitmap = BitmapFactory
                            .decodeByteArray(bytesFromURL, 0, bytesFromURL.length);
                    Drawable drawable = new BitmapDrawable(bitmap);
                    emblems.put(link, drawable);
                } finally {
                    connection.disconnect();
                }
            }
        }
        return emblems;
    }
}
