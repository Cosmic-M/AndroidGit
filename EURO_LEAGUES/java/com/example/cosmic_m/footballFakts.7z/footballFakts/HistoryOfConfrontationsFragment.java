package com.example.cosmic_m.footballFakts;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by Cosmic_M on 29.06.2017.
 */

public class HistoryOfConfrontationsFragment extends Fragment {

    private static final String TAG = "HistoryOfConfrontations";
    private SingletonLeague mSingletonLeague;
    private RecyclerView mResyclerView;
    private String mConfrontationId;
    private List<Event> mItems = new ArrayList<>();

    public static Fragment newInstance(){
        return new HistoryOfConfrontationsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
//        mConfrontationId = getActivity().getIntent().getStringExtra("confrontationId");
        Bundle bundle = getArguments();
        if (bundle != null) {
            mConfrontationId = bundle.getString("confrontationId");
        }
        mSingletonLeague = SingletonLeague.getSingleton(getActivity());
        new BackgroundTask().execute(mConfrontationId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_for_recycler_view, container, false);
        mResyclerView = (RecyclerView) view.findViewById(R.id.recycler_id);
        mResyclerView.setLayoutManager(new
                LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        setupAdapter();
        return view;
    }

    private void setupAdapter(){
        if (this.isAdded()){
            mResyclerView.setAdapter(new ListMatchesAdapter(mItems));
        }
    }

    private class ListMatchesHolder extends RecyclerView.ViewHolder {
        private TextView mHomeTeam;
        private ImageView mImageHomeTeam;
        private TextView mScoreOfMatch;
        private ImageView mImageAwayTeam;
        private TextView mAwayTeam;
        private TextView mDateOfMatch;

        ListMatchesHolder(View itemView){
            super(itemView);
            mHomeTeam = (TextView) itemView.findViewById(R.id.home_team);
            mImageHomeTeam = (ImageView) itemView.findViewById(R.id.image_home_team);
            mImageHomeTeam.setBackgroundColor(Color.TRANSPARENT);
            mImageHomeTeam.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            mScoreOfMatch = (TextView) itemView.findViewById(R.id.score_of_match);
            mImageAwayTeam = (ImageView) itemView.findViewById(R.id.image_away_team);
            mImageAwayTeam.setBackgroundColor(Color.TRANSPARENT);
            mImageAwayTeam.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            mAwayTeam = (TextView) itemView.findViewById(R.id.away_team);
            mDateOfMatch = (TextView) itemView.findViewById(R.id.date_of_match);
        }

        public void bindEvents(Event event){
            mHomeTeam.setText(event.getHomeTeamName());
            mAwayTeam.setText(event.getAwayTeamName());
            mImageHomeTeam.setImageDrawable(mSingletonLeague
                    .getTeamDrawable(mHomeTeam.getText().toString()));
            mScoreOfMatch.setText(event.getGoalsHomeTeam() + " : " + event.getGoalsAwayTeam());
            mImageAwayTeam.setImageDrawable(mSingletonLeague
                    .getTeamDrawable(mAwayTeam.getText().toString()));
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss'Z'");
            Date result;
            String dateOfMatch = "";
            try {
                result = df.parse(event.getMatchDate());
                Log.i(TAG, "result = df.parse(event.getMatchDate())");
                SimpleDateFormat sdfForDate = new SimpleDateFormat("dd MMMM, yyyy");
                SimpleDateFormat sdfForTime = new SimpleDateFormat("HH:mm");
                sdfForDate.setTimeZone(TimeZone.getTimeZone("GMT"));
                sdfForTime.setTimeZone(TimeZone.getTimeZone("GMT"));
                dateOfMatch = sdfForDate.format(result);
            }
            catch(java.text.ParseException e){
                Log.i(TAG, e.getMessage());
                e.printStackTrace();
            }
            //mDateOfMatch.setText(event.getMatchDate());
            mDateOfMatch.setText(dateOfMatch);
        }
    }

    private class ListMatchesAdapter extends RecyclerView.Adapter<ListMatchesHolder>{
        private List<Event> mItems;

        public ListMatchesAdapter(List<Event> items){
            mItems = items;
        }

        @Override
        public ListMatchesHolder onCreateViewHolder(ViewGroup viewGroup, int itemView){
            LayoutInflater inflater = LayoutInflater.from(getActivity());
            View view = inflater.inflate(R.layout.item_historical_confrontation, viewGroup, false);
            return new ListMatchesHolder(view);
        }

        @Override
        public void onBindViewHolder(ListMatchesHolder holder, int position){
            Event event = mItems.get(position);
            holder.bindEvents(event);
        }

        @Override
        public int getItemCount(){
            return mItems.size();
        }
    }

    private class BackgroundTask extends AsyncTask<String, Void, List<Event>> {

        @Override
        protected List<Event> doInBackground(String...params){
            String link = params[0];
            List<Event> listOfConfrontatioin = null;
            try {
                listOfConfrontatioin = new APILoader().fetchItemsHistory(link);
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return listOfConfrontatioin;
        }

        @Override
        public void onPostExecute(List<Event> list){
            mItems = list;
            setupAdapter();
        }
    }
}
