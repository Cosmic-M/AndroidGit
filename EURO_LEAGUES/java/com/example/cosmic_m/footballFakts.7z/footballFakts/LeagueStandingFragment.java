package com.example.cosmic_m.footballFakts;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.cosmic_m.footballFakts.database.SchemaDB.TeamStandingTable;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class LeagueStandingFragment extends Fragment {
    private static final String TAG = "LeagueStandingFragment";
    private TeamStanding mTeamStanding;
    private Map<String, Event> mEventMap;
    private RecyclerView mPhotoRecyclerView;
    private List<TeamStanding.Standing> mItems = new ArrayList<>();
    private ThumbnailDownloader<StandingHolder> mThumbnailDownloader;
    private int mIdLeague;
    private int mNumberOfTeams;
    private String mLeagueCaption;
    private String mLeagueCaptionWithoutYear;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        Bundle bundle = getArguments();
        if (bundle != null) {
            mIdLeague = bundle.getInt("id");
            mNumberOfTeams = bundle.getInt("numberOfTeams");
            mLeagueCaption = bundle.getString("leagueCaption");
        }
        int index = mLeagueCaption.lastIndexOf("20");
        mLeagueCaptionWithoutYear = mLeagueCaption.substring(0, index).trim();
        Log.i(TAG, "mLeagueCaptionWithoutYear = " + mLeagueCaptionWithoutYear);
        new FetchItemsTask().execute();
        //new FetchItemsTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
//        Handler responseHandler = new Handler();
//        mThumbnailDownloader = new ThumbnailDownloader<>(responseHandler);
//        mThumbnailDownloader.start();
//        mThumbnailDownloader.getLooper();
//        mThumbnailDownloader.setThumbnailDownloadListener(new ThumbnailDownloader
//                .ThumbnailDownloadListener<StandingHolder>() {
//            @Override
//            public void onThumbnailDownloaded(StandingHolder target, Drawable drawable) {
//                target.bindDrawable(drawable);
//            }
//        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_standing_teams, container, false);
        mPhotoRecyclerView = (RecyclerView) view
                .findViewById(R.id.fragment_standing_teams_id);
        mPhotoRecyclerView.setLayoutManager(
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        setupAdapter();

        return view;
    }

    private void setupAdapter() {
        if (this.isAdded()) {
            mPhotoRecyclerView.setAdapter(new TeamAdapter(mItems));
        }
    }

    private class SeparatorHolder extends RecyclerView.ViewHolder{
        private TextView mGroup;

        public SeparatorHolder(View itemView){
            super(itemView);
            mGroup = (TextView) itemView.findViewById(R.id.group_id);
        }

        public void bindItem(TeamStanding.Standing item){
            mGroup.setText("GROUP: " + item.getGroup());
        }
    }

    private class StandingHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mPosition;
        private ImageView mEmblem;
        private TextView mTeam;
        private String mTeamId;
        private TextView mWinGames;
        private TextView mDrawGames;
        private TextView mLossGames;
        private TextView mPlayedGames;
        private TextView mGoalScoredAndMissedGoals;
        private TextView mPts;
        private ImageView preOneMatchDay;
        private ImageView preTwoMatchDay;
        private ImageView preThreeMatchDay;
        private ImageView preFourMatchDay;
        private ImageView preFiveMatchDay;

        public StandingHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            mTeam = (TextView) itemView.findViewById(R.id.team_name);
            mEmblem = (ImageView) itemView.findViewById(R.id.image_id);
            mEmblem.setBackgroundColor(Color.TRANSPARENT);
            mEmblem.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            mPosition = (TextView) itemView.findViewById(R.id.position);
            mPlayedGames = (TextView) itemView.findViewById(R.id.played_matches);
            mWinGames = (TextView) itemView.findViewById(R.id.win_games);
            mDrawGames = (TextView) itemView.findViewById(R.id.draw_games);
            mLossGames = (TextView) itemView.findViewById(R.id.loss_games);
            mGoalScoredAndMissedGoals = (TextView) itemView
                    .findViewById(R.id.goal_scored_and_missed_goals);
            mPts = (TextView) itemView.findViewById(R.id.points);
            preOneMatchDay = (ImageView)itemView.findViewById(R.id.matchDay1);
            preTwoMatchDay = (ImageView)itemView.findViewById(R.id.matchDay2);
            preThreeMatchDay = (ImageView)itemView.findViewById(R.id.matchDay3);
            preFourMatchDay = (ImageView)itemView.findViewById(R.id.matchDay4);
            preFiveMatchDay = (ImageView)itemView.findViewById(R.id.matchDay5);
        }

        public void bindDrawable(Drawable drawable){
            if (drawable != null) {
                mEmblem.setImageDrawable(drawable);
            }
            else{
                mEmblem.setImageResource(R.mipmap.devil);
            }
        }

        public void bindItem(TeamStanding.Standing item) {
            mTeamId = item.getTeamId();
            mTeam.setText(item.getTeam());
            mPosition.setText(item.getRank());
            mPlayedGames.setText(item.getPlayedGames());
            mWinGames.setText(item.getWinGames());
            mDrawGames.setText(item.getDrawGames());
            mLossGames.setText(item.getLossGames());
            Drawable drawable = SingletonLeague.getSingleton(getActivity()).getEmblemDrawable(item.getTeamId());
            mEmblem.setImageDrawable(drawable);
            mGoalScoredAndMissedGoals.setText(item
                    .getGoals() + "-" + item.getGoalsAgainst());
            mPts.setText(item.getPts());
            int[] mass = item.getMassOfLastResults();
            ImageView[] images = {preOneMatchDay, preTwoMatchDay,
                    preThreeMatchDay, preFourMatchDay, preFiveMatchDay};
            for (int i = 0; i < mass.length; i++) {
                switch (mass[i]) {
                    case 1:
                        images[i].setImageResource(R.drawable.gray_circle);
                        break;
                    case -1:
                        images[i].setImageResource(R.drawable.red_circle);
                        break;
                    case 3:
                        images[i].setImageResource(R.drawable.green_circle);
                        break;
                    default:
                        images[i].setVisibility(View.INVISIBLE);
                        break;
                }
            }
        }

        @Override
        public void onClick(View view){

            ListAllMatchesOfTeamFragment lamf = new ListAllMatchesOfTeamFragment();
            Bundle bundle = new Bundle();
            bundle.putString("team_id", mTeamId);
            bundle.putString("league_id", String.valueOf(mIdLeague));
            bundle.putString("leagueCaption", mLeagueCaption);
            lamf.setArguments(bundle);
            FragmentManager fragmentManager = getFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.fragment_container,  lamf)
                    .addToBackStack("").commit();
        }
    }

    private class TeamAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        private List<TeamStanding.Standing> mStandings;

        public TeamAdapter(List<TeamStanding.Standing> standings) {
            mStandings = standings;
        }

        @Override
        public int getItemViewType(int position){
            if ((position % 5) == 0 && mLeagueCaptionWithoutYear.equals("Champions League")){
                return 0;
            }
            else{
                return 1;
            }
        }

        @Override
        public RecyclerView.ViewHolder  onCreateViewHolder(ViewGroup viewGroup, int viewType) {
            RecyclerView.ViewHolder viewHolder = null;
            LayoutInflater inflater;
            View view;

            switch (viewType) {
                case 0:
                    inflater = LayoutInflater.from(getActivity());
                    view = inflater.inflate(R.layout.separator_group_item, viewGroup, false);
                    viewHolder =  new SeparatorHolder(view);
                    break;
                case 1:
                    inflater = LayoutInflater.from(getActivity());
                    view = inflater.inflate(R.layout.container_item_recycler_view, viewGroup, false);
                    viewHolder =  new StandingHolder(view);
                    break;
            }
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            switch (this.getItemViewType(position)) {
                case 0:
                    SeparatorHolder separatorHolder = (SeparatorHolder) holder;
                    TeamStanding.Standing tS = mStandings.get(position);
                    separatorHolder.bindItem(tS);
                    break;
                case 1:
                    StandingHolder standingHolder = (StandingHolder) holder;
                    TeamStanding.Standing teamStanding = mStandings.get(position);
                    if (mLeagueCaptionWithoutYear.equals("Champions League")) {
                        teamStanding.setRank(String.valueOf(position % 5));
                    }
                    standingHolder.bindItem(teamStanding);
//                    Drawable devilPicture = getResources().getDrawable(R.mipmap.devil);
//                    standingHolder.bindDrawable(devilPicture);
                    //mThumbnailDownloader.queueThumbnail(standingHolder, teamStanding.getResourceOfPicture());
                    break;
            }
        }

        @Override
        public int getItemCount() {
            return mStandings.size();
        }
    }

//    @Override
//    public void onDestroy(){
//        super.onDestroy();
//        mThumbnailDownloader.quit();
//        Log.i(TAG, "background thread stopped");
//    }

//    @Override
//    public void onDestroyView(){
//        super.onDestroyView();
//        mThumbnailDownloader.clearQueue();
//    }

    private class FetchItemsTask extends AsyncTask<Void,Void,TeamStanding> {
        Map<String, Event> eventMap;
        TeamStanding ts;

        @Override
        protected TeamStanding doInBackground(Void... params) {
            TeamStanding ts = null;
            String link;
            link = "http://api.football-data.org/v1/competitions/"
                        + String.valueOf(mIdLeague)+ "/leagueTable/";
            try {
                Map<String, TeamStanding> map = new APILoader().fetchItems(link, getActivity(), String.valueOf(mIdLeague));
                ts = map.get(String.valueOf(mIdLeague));
                String[] links = new String[ts.getStanding().values().size()];
                int i = 0;
                long begin = System.currentTimeMillis();
                for (TeamStanding.Standing standing : ts.getStanding().values()){
                    links[i++] = standing.getResourceOfPicture();
                }
                Map<String, Drawable> result = new HashMap<>();
                Future<Map<String, Drawable>> f1 = null;
                Future<Map<String, Drawable>> f2 = null;
                Future<Map<String, Drawable>> f3 = null;
                Future<Map<String, Drawable>> f4 = null;
                Future<Map<String, Drawable>> f5 = null;
                Future<Map<String, Drawable>> f6 = null;
                Future<Map<String, Drawable>> f7 = null;
                Future<Map<String, Drawable>> f8 = null;
                ExecutorService es = Executors.newFixedThreadPool(8);
                if (links.length <= 20) {
                    f1 = es.submit(new EmblemClubFetcher(new String[]{links[0], links[1], links[2]}));
                    f2 = es.submit(new EmblemClubFetcher(new String[]{links[3], links[4], links[5]}));
                    f3 = es.submit(new EmblemClubFetcher(new String[]{links[6], links[7], links[8]}));
                    f4 = es.submit(new EmblemClubFetcher(new String[]{links[9], links[10], links[11]}));
                    f5 = es.submit(new EmblemClubFetcher(new String[]{links[12], links[13]}));
                    f6 = es.submit(new EmblemClubFetcher(new String[]{links[14], links[15]}));
                    f7 = es.submit(new EmblemClubFetcher(new String[]{links[16], links[17]}));
                    if (links.length == 20) {
                        f8 = es.submit(new EmblemClubFetcher(new String[]{links[18], links[19]}));
                    }
                }
                    else{
                        f1 = es.submit(new EmblemClubFetcher(new String[]{links[0], links[1], links[2], links[3]}));
                        f2 = es.submit(new EmblemClubFetcher(new String[]{links[4], links[5], links[6], links[7]}));
                        f3 = es.submit(new EmblemClubFetcher(new String[]{links[8], links[9], links[10], links[11]}));
                        f4 = es.submit(new EmblemClubFetcher(new String[]{links[12], links[13], links[14], links[15]}));
                        f5 = es.submit(new EmblemClubFetcher(new String[]{links[16], links[17], links[18], links[19]}));
                        f6 = es.submit(new EmblemClubFetcher(new String[]{links[20], links[21], links[22], links[23]}));
                        f7 = es.submit(new EmblemClubFetcher(new String[]{links[24], links[25], links[26], links[27]}));
                        f8 = es.submit(new EmblemClubFetcher(new String[]{links[28], links[29], links[30], links[31]}));
                    }

                try {
                    result.putAll(f1.get());
                    result.putAll(f2.get());
                    result.putAll(f3.get());
                    result.putAll(f4.get());
                    result.putAll(f5.get());
                    result.putAll(f6.get());
                    result.putAll(f7.get());
                    result.putAll(f8.get());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

//                ts = map.get(String.valueOf(mIdLeague));
//                for (TeamStanding.Standing standing : ts.getStanding().values()) {
//                    String url = standing.getResourceOfPicture();
//                    String teamId = standing.getTeamId();
//                    Drawable drawable;
//                    try {
//                        drawable = new EmblemClubFetcher().getUrlBytes(url);
//                    }
//                    catch(IOException exc){
//                        exc.getMessage();
//                        drawable = null;
//                    }
//                    SingletonLeague.getSingleton(getActivity()).setEmblemDrawable(teamId, drawable);
//                    Log.i(TAG, "url = " + url);
//                    Log.i(TAG, "teamId = " + teamId);
//                }
                long fin = System.currentTimeMillis();
                Log.i(TAG, "total time for loading emblems = " + (fin - begin) + " ms");
//                long start = System.currentTimeMillis();
//                Log.i(TAG, "ts = null =>" + Boolean.valueOf(ts == null));
//                SingletonLeague.getSingleton(getActivity()).updateAndInsertTeamStanding(ts);
//                long end = System.currentTimeMillis();
//                Log.i(TAG, "total time for update database = " + (end - start) + " ms");
            }
            catch (IOException e) {
                Log.i(TAG, "IOException " + e.getMessage());
                Map<String, TeamStanding> map = SingletonLeague
                        .getSingleton(getActivity()).getTeamsStandingMap(TeamStandingTable.Cols.LEAGUE_CAPTION + " =? ", new String[]{mLeagueCaption});
                Log.i(TAG, "mLeagueCaption = " + mLeagueCaption);
                ts = map.get(mLeagueCaption);
                e.printStackTrace();
            } catch (JSONException e) {
                Log.i(TAG, "JSONEXCEPTION " + e.getMessage());
                e.printStackTrace();
            }
            Log.i(TAG, "mIdLeague => " + mIdLeague);
            String matchDay = ts.getMatchDay();
            link = "http://api.football-data.org/v1/competitions/" +
                    String.valueOf(mIdLeague) + "/fixtures";

            APILoader apiLoader = new APILoader();
            //Map<String, Event> eventMap;
            List<Event> listOfEvent = new ArrayList<>();
            try {
                eventMap = apiLoader.fetchEvents(link);
//                long start = System.currentTimeMillis();
//                SingletonLeague.getSingleton(getActivity()).updateAndInsertEvents(eventMap);
//                long end = System.currentTimeMillis();
//                Log.i(TAG, "total time for update database = " + (end - start) + " ms");
                listOfEvent = new ArrayList<>(eventMap.values());
            } catch (IOException e) {
                Log.i(TAG, "IOException: " + e.getMessage());
                eventMap = SingletonLeague.getSingleton(getActivity()).getEventMap(null, null);
                listOfEvent = new ArrayList<>(eventMap.values());
                for (int i = 0; i < listOfEvent.size(); i++){
                    if (Integer.parseInt(listOfEvent.get(i).getCompetitionId()) != mIdLeague){
                        listOfEvent.remove(i--);
                    }
                }
                e.printStackTrace();
            } catch (JSONException e) {
                Log.i(TAG, "JSONException: " + e.getMessage());
                e.printStackTrace();
            }
            Log.i(TAG, "ts.getStanding.size() = " + ts.getStanding().size());
            ts = apiLoader.fetchFiveLastResults(ts, listOfEvent, getActivity(), mLeagueCaption, Integer.parseInt(matchDay));
            return  ts;
        }

        @Override
        protected void onPostExecute(TeamStanding teamStanding) {
            mEventMap = eventMap;
            mTeamStanding = ts;
            Collection<TeamStanding.Standing> collection = teamStanding.getStanding().values();
            Comparator comparator;
            Set<TeamStanding.Standing> set;
            if (mLeagueCaptionWithoutYear.equals("Champions League")){
                String[] group = new String[]{"A", "B", "C", "D", "E", "F", "G", "H"};
                comparator = new ComparatorForGroupStage();
                set = new TreeSet<>(comparator);
                for (String someGroup : group){
                    TeamStanding.Standing standing = new TeamStanding().createNewStandingClass();
                    standing.setGroup(someGroup);
                    standing.setPts("19");//comparator set this item in head of group
                    standing.setGoalsDifference("0");//not important because... watch previous string
                    set.add(standing);
                }
            }
            else {
                comparator = new CustomComparator(mNumberOfTeams);
                set = new TreeSet<>(comparator);
            }
            set.addAll(collection);
            mItems = new ArrayList<>(set);
            setupAdapter();
            Log.i(TAG, "onPostExecute in FetchItemsTask finished");
            Log.i(TAG, "InsertAndUpdateTeamStandingInDataBase() started");
            new InsertAndUpdateTeamStandingInDataBase().execute(mTeamStanding);
            Log.i(TAG, "InsertAndUpdateEventsInDataBase() started");
            new InsertAndUpdateEventsInDataBase().execute(mEventMap);
        }
    }

    private class InsertAndUpdateTeamStandingInDataBase extends AsyncTask<TeamStanding,Void,Void> {

        @Override
        protected Void doInBackground(TeamStanding...params){
            Log.i(TAG, "params in InsertAndUpdateTeamStandingInDataBase => " + (params[0] == null));
            SingletonLeague.getSingleton(getActivity()).updateAndInsertTeamStanding(params[0]);
            return null;
        }
    }

    private class InsertAndUpdateEventsInDataBase extends AsyncTask<Map<String, Event>,Void,Void> {

        @Override
        protected Void doInBackground(Map<String, Event>...params){
            Log.i(TAG, "params in InsertAndUpdateEventsInDataBase => " + (params[0] == null));
            SingletonLeague.getSingleton(getActivity()).updateAndInsertEvents(params[0]);
            return null;
        }
    }
}
